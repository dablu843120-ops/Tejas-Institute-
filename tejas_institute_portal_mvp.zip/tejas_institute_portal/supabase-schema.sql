-- Starter schema for a production Supabase migration.
-- Review policies and add server-side grading functions before real use.
create type public.app_role as enum ('admin','student');
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'student',
  class_number int check (class_number between 1 and 12),
  student_code text unique
);
create table public.exams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  class_number int not null check (class_number between 1 and 12),
  subject text not null,
  duration_minutes int not null check (duration_minutes > 0),
  marks_per_question numeric not null default 1,
  negative_marks numeric not null default 0,
  starts_at timestamptz,
  ends_at timestamptz,
  published boolean not null default false,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create table public.questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  position int not null,
  question_text jsonb not null, -- e.g. {"en":"...","hi":"..."}
  options jsonb not null,       -- localized option content
  correct_option smallint not null check (correct_option between 0 and 3),
  unique(exam_id, position)
);
create table public.exam_attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id),
  student_id uuid not null references public.profiles(id),
  started_at timestamptz not null default now(),
  submitted_at timestamptz,
  status text not null default 'in_progress' check (status in ('in_progress','submitted','expired')),
  score numeric,
  correct_count int,
  wrong_count int,
  unattempted_count int,
  unique(exam_id, student_id)
);
create table public.responses (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.exam_attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id),
  selected_option smallint check (selected_option between 0 and 3),
  marked_for_review boolean not null default false,
  saved_at timestamptz not null default now(),
  unique(attempt_id, question_id)
);
alter table public.profiles enable row level security;
alter table public.exams enable row level security;
alter table public.questions enable row level security;
alter table public.exam_attempts enable row level security;
alter table public.responses enable row level security;

-- Do not add broad public policies. Add narrowly scoped policies only after
-- defining trusted admin provisioning and server-side grading workflows.
